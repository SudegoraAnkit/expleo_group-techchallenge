package org.expleo.sarch.dsl.generator.json_model;

import java.util.List;

public class ComponentDto {
	public String name;
    public List<PortDto> ports;
}
