package org.expleo.sarch.dsl.generator.json_model;

public class PortDto {
	 public String name;
	 public String type; 
	 public String interfaceName;
}
