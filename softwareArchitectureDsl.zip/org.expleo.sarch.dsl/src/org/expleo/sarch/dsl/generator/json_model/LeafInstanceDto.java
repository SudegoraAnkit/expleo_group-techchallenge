package org.expleo.sarch.dsl.generator.json_model;

public class LeafInstanceDto {
	public String type;
    public String name;
}
