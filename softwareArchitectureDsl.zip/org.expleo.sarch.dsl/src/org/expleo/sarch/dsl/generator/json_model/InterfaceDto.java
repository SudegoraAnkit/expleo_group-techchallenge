package org.expleo.sarch.dsl.generator.json_model;

import java.util.List;

public class InterfaceDto {
	public String name;
    public List<ElementDto> elements;
}
