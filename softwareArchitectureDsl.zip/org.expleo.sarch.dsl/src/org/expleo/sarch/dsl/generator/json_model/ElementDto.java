package org.expleo.sarch.dsl.generator.json_model;

public class ElementDto {
	 public String name;
	 public String dataType;
}
